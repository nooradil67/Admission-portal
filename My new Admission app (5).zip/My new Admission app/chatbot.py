import requests
import json
from datetime import datetime
from pymongo import MongoClient
import re
import os
from flask import Flask, render_template,send_from_directory, request, jsonify
import threading
import webbrowser
import sys
import atexit

app = Flask(__name__)

# Database connection
client = MongoClient("mongodb://localhost:27017")
db = client["admission_office"]
students_collection = db["students"]

# Create personal_data.txt if it doesn't exist with the required content
if not os.path.exists("personal_data.txt"):
    with open("personal_data.txt", "w", encoding="utf-8") as f:
        f.write("""🎓 1. General HEC Eligibility Guidelines for BS Admissions
Degree Duration: All BS programs are 4 years long with 124–160 credit hours.

Minimum Qualification: Students must have completed 12 years of education (Intermediate: FSc, ICS, FA, ICom, DAE, etc.).

Minimum Marks: Most universities require at least 50–60% marks in intermediate.

Merit Criteria: Admission is usually based on intermediate marks + university entry test (if applicable).

2. Program-wise Eligibility Based on Intermediate Stream

A) ICS (Intermediate in Computer Science)
Eligible for: BS Computer Science (BSCS), BS IT, BS Data Science, BS AI, BS Software Engineering
Must have studied Mathematics + Computer Science/Physics/Statistics.
Minimum 50% marks. If Math was not studied, deficiency course (6 credit hours) required.

B) FSc Pre-Engineering
Eligible for: BS Engineering (Electrical, Mechanical, Civil, etc.), BSCS, BS IT, BS Data Science
Must have Math, Physics, Chemistry. Minimum 60% marks. ECAT test required for engineering.

C) FSc Pre-Medical
Eligible for: BS Biotechnology, BS Zoology, BS Botany, BS Biochemistry, BS Nutrition, BS Nursing
Must have Biology. Minimum 50–60% marks. BSCS/IT possible only with additional Math or deficiency course.

D) ICom (Intermediate in Commerce)
Eligible for: BBA, BS Accounting & Finance, BS Commerce, BS Economics, BS Banking & Finance
Typically 60% marks. Not eligible for Engineering or BSCS without Math.

E) FA (Intermediate in Arts/Humanities)
Eligible for: BS English, BS Mass Communication, BS IR, BS Psychology, BS Education, BS Sociology, etc.
Entry test or portfolio may be required. Not eligible for technical programs.

F) DAE (Diploma of Associate Engineering)
Eligible for: BS Engineering Technology programs in relevant fields. May grant credit transfer or advanced standing.
Some universities allow BS Engineering admission with additional conditions.

3. Deficiency Courses and Special Cases
Students without Math for BSCS/IT must study a 6-credit Math deficiency course during first year.
Foreign or diploma holders must apply for HEC equivalence via eservices.hec.gov.pk.
Some universities allow switching fields with bridging/deficiency courses.

🎓 NUST University Eligibility Example:
- BS Computer Science: FSc Pre-Engineering or ICS with 60% marks + NUST Entry Test.
- BS Software Engineering: FSc Pre-Engineering or ICS with Math + Entry Test.
- Fee discounts: Above 85% marks in intermediate = up to 30% fee waiver; Above 90% = up to 50% waiver.

🎓 GIKI University Eligibility Example:
- BS Computer Engineering: FSc Pre-Engineering with 60% marks + GIKI Admission Test.
- Scholarships: Top 10% test scorers get merit scholarships covering 25-100% tuition.

🎓 COMSATS University Eligibility Example:
- BSCS: ICS with Math, minimum 50% marks + NTS test.
- BS Electrical Engineering: FSc Pre-Engineering with 60% marks + NTS test.
- Scholarships: Above 80% marks = 20% discount, Above 90% = 40% discount.
""")

# Updated interview questions in specific order
fixed_questions = [
    # Personal Information
    {"question": "What is your full name?", "field": "full_name", "type": "name"},
    {"question": "What is your father's name?", "field": "father_name", "type": "name"},
    {"question": "What is your date of birth?", "field": "dob", "type": "date"},
    {"question": "What is your gender? (Male / Female / Other)", "field": "gender", "type": "gender"},
    {"question": "What is your CNIC or B-Form number?", "field": "cnic", "type": "id"},
    {"question": "What is your email address?", "field": "email", "type": "email"},
    {"question": "What is your mobile number?", "field": "mobile", "type": "phone"},
    {"question": "Which city are you from?", "field": "city", "type": "location"},
    
    # Matriculation (10th Grade) Details
    {"question": "Which education board did you complete your Matric from?", "field": "matric_board", "type": "education"},
    {"question": "What was your group/stream? (Science / Arts / Computer Science)", "field": "matric_stream", "type": "education"},
    {"question": "In which year did you pass Matric?", "field": "matric_year", "type": "year"},
    {"question": "What were the total marks?", "field": "matric_total", "type": "marks"},
    {"question": "How many marks did you obtain?", "field": "matric_obtained", "type": "marks"},
    {"question": "What was the name of your school?", "field": "matric_school", "type": "institution"},
    
    # Intermediate (FA/FSc/ICS/I.Com) Details
    {"question": "Which board did you complete Intermediate from?", "field": "inter_board", "type": "education"},
    {"question": "What was your program? (FSc Pre-Medical / Pre-Engineering / ICS / I.Com / FA)", "field": "inter_program", "type": "education"},
    {"question": "In which year did you complete Intermediate?", "field": "inter_year", "type": "year"},
    {"question": "What were the total marks?", "field": "inter_total", "type": "marks"},
    {"question": "How many marks did you obtain?", "field": "inter_obtained", "type": "marks"},
    {"question": "What was the name of your college?", "field": "inter_college", "type": "institution"},
    
    # BS Program Preference
    {"question": "Which field/program would you like to apply for?", "field": "program_choice", "type": "program"},
    {"question": "Why do you want to choose this program?", "field": "program_reason", "type": "text"},
    {"question": "Do you prefer morning or evening classes?", "field": "class_preference", "type": "preference"},
    {"question": "Are you comfortable attending online classes if required?", "field": "online_comfort", "type": "preference"},
    
    # Aptitude & Interest-Based Questions
    {"question": "Do you enjoy solving logical puzzles or math problems? (Yes / No)", "field": "logical_aptitude", "type": "yesno"},
    {"question": "How familiar are you with computers and technology? (Rate from 1 to 5)", "field": "tech_familiarity", "type": "rating"},
    {"question": "Do you prefer working with numbers or with people? (Numbers / People / Both)", "field": "work_preference", "type": "preference"},
    {"question": "Do you have any prior programming experience? (Yes / No)", "field": "programming_experience", "type": "yesno"},
    {"question": "Do you prefer a theoretical learning environment or practical?", "field": "learning_preference", "type": "preference"},
    
    # Document Upload Confirmation
    {"question": "Are you ready to upload the following documents?\n- Matriculation Result Card\n- Intermediate Result Card\n- CNIC / B-Form\n- Passport-sized Photograph", "field": "documents_ready", "type": "yesno"}
]

def retrieve_relevant_data(user_prompt, data_file="personal_data.txt"):
    """Search personal data file for relevant information"""
    try:
        with open(data_file, "r", encoding="utf-8") as f:
            data_lines = f.readlines()

        keywords = user_prompt.lower().split()
        matched_lines = []
        for line in data_lines:
            for kw in keywords:
                if kw in line.lower():
                    matched_lines.append(line.strip())
                    break

        return "\n".join(matched_lines) if matched_lines else "No direct matches found in personal data."

    except FileNotFoundError:
        return "Personal data file not found."

def clean_extracted_text(text):
    """Clean and standardize extracted text"""
    if not text:
        return ""
    text = ' '.join(text.split())
    text = re.sub(r'\b(?:i|am|is|are|was|were|my|the|a|an|from|in|at)\b', '', text, flags=re.IGNORECASE)
    text = re.sub(r'[^a-zA-Z0-9. ]', '', text)
    return text.strip()

def extract_info(answer, question_type):
    """Extract essential information from answers"""
    if not answer:
        return ""
    
    answer = answer.lower().strip()
    
    if question_type == "name":
        name = re.sub(r'^(hi|hello|hey|my name is|i am|name is|im|this is|is)\s*', '', answer)
        return clean_extracted_text(name).title()
    elif question_type == "date":
        date = re.search(r'(\d{2}[/-]\d{2}[/-]\d{4})|(\d{4}[/-]\d{2}[/-]\d{2})', answer)
        return date.group() if date else clean_extracted_text(answer)
    elif question_type == "gender":
        gender = re.search(r'(male|female|other)', answer)
        return gender.group().title() if gender else "Other"
    elif question_type == "id":
        id_num = re.search(r'\d{5}-\d{7}-\d{1}|\d{13}', answer)
        return id_num.group() if id_num else clean_extracted_text(answer)
    elif question_type == "email":
        email = re.search(r'[\w\.-]+@[\w\.-]+', answer)
        return email.group() if email else clean_extracted_text(answer)
    elif question_type == "phone":
        phone = re.search(r'\d{4}-\d{7}', answer)
        return phone.group() if phone else clean_extracted_text(answer)
    elif question_type == "location":
        return clean_extracted_text(answer).title()
    elif question_type == "education":
        return clean_extracted_text(answer).upper()
    elif question_type == "year":
        year = re.search(r'\d{4}', answer)
        return year.group() if year else "N/A"
    elif question_type == "marks":
        marks = re.search(r'(\d+\.?\d*)', answer)
        return marks.group(1) if marks else "N/A"
    elif question_type == "institution":
        return clean_extracted_text(answer).title()
    elif question_type == "program":
        return clean_extracted_text(answer).upper()
    elif question_type == "text":
        return clean_extracted_text(answer)
    elif question_type == "preference":
        return clean_extracted_text(answer).capitalize()
    elif question_type == "yesno":
        yesno = re.search(r'(yes|no)', answer)
        return yesno.group().capitalize() if yesno else "No"
    elif question_type == "rating":
        rating = re.search(r'[1-5]', answer)
        return rating.group() if rating else "3"
    
    return clean_extracted_text(answer)

def determine_field(program_choice, inter_program):
    """Determine student's field category"""
    pc = (program_choice or "").lower()
    ip = (inter_program or "").lower()

    if any(word in pc for word in ["mbbs", "doctor", "medicine", "medical"]) or "pre-medical" in ip:
        return "Medical"
    elif any(word in pc for word in ["cs", "computer", "software", "it", "ai"]) or "ics" in ip or "computer" in ip:
        return "IT"
    elif any(word in pc for word in ["business", "commerce", "bba", "mba"]) or "commerce" in ip:
        return "Business"
    elif any(word in pc for word in ["engineering", "electrical", "mechanical", "civil"]) or "engineering" in ip:
        return "Engineering"
    else:
        return "General"

def ask_ai(prompt, context=None, mode="general"):
    """Call local LLM with appropriate prompt based on mode"""
    try:
        url = "http://localhost:11434/api/generate"
        headers = {"Content-Type": "application/json"}
        
        if mode == "interview":
            if context.get("current_question_index", 0) >= len(fixed_questions):
                return "Thank you for your time. This concludes your admission interview. We will contact you soon."
            
            base_question = fixed_questions[context["current_question_index"]]["question"]
            
            full_prompt = f"""
IMPORTANT RULES:
- You are an admission interviewer asking questions to a student.
- You MUST ask about: {base_question}
- REPHRASE this question in a natural, conversational way.
- Ask ONLY ONE question.
- Use student's name if known.
- Reply politely in human interviewer tone.
- DO NOT add any extra text or explanations.

Conversation context:
{context.get("conversation_history", "")}

Please rephrase this question naturally: "{base_question}"
"""
            data = {
                "model": "gemma:2b",
                "prompt": full_prompt,
                "stream": False
            }
        elif mode == "recommendation":
            field = determine_field(context.get("program_choice"), context.get("inter_program"))
            
            full_prompt = f"""
You are an expert admission counselor. Suggest only 2-3 programs from this field: {field}.

Student Details:
Name: {context.get("full_name", "Not Provided")}
Matric: {context.get("matric_obtained", "N/A")}/{context.get("matric_total", "N/A")} from {context.get("matric_board", "N/A")}
Intermediate: {context.get("inter_program", "N/A")} - {context.get("inter_obtained", "N/A")}/{context.get("inter_total", "N/A")}
Program Choice: {context.get("program_choice", "Not Provided")}

🔴 STRICT Guidelines:
- Only suggest programs directly related to {field} field.
- Do NOT suggest any program outside {field} field.
- For each program, give a short reason why it suits them based on their education and marks.
- Suggest 2-3 good universities in Pakistan offering each program.
- Output ONLY in this EXACT format:

Program: [Program Name]
Reason: [Short reason]
Universities: [Uni1], [Uni2], [Uni3]

Repeat this block for each suggested program. Do NOT include headings, explanations, or extra text. Strictly follow the format.
"""
            data = {
                "model": "gemma:2b",
                "prompt": full_prompt
            }
        else:  # general chat mode
            context = retrieve_relevant_data(prompt)
            
            full_prompt = f"""
You are an AI university admission assistant.
Use the following personal data context to answer clearly and accurately.

Personal Data Context:
{context}

User Question:
{prompt}
"""
            data = {
                "model": "gemma:2b",
                "prompt": full_prompt
            }

        response = requests.post(url, json=data, headers=headers)
        response.raise_for_status()

        responses = response.text.strip().split('\n')
        all_outputs = []
        for line in responses:
            if line.strip():
                obj = json.loads(line)
                if 'response' in obj:
                    all_outputs.append(obj['response'])

        return " ".join(all_outputs).replace("  ", " ").strip()

    except requests.exceptions.HTTPError as e:
        return f"API Error: {str(e)}"
    except Exception as e:
        return f"System error: {str(e)}"

# Updated global state for the interview
interview_state = {
    "mode": "menu",
    "student_data": {
        # Personal Information
        "full_name": "",
        "father_name": "",
        "dob": "",
        "gender": "",
        "cnic": "",
        "email": "",
        "mobile": "",
        "city": "",
        
        # Matriculation Details
        "matric_board": "",
        "matric_stream": "",
        "matric_year": "",
        "matric_total": "",
        "matric_obtained": "",
        "matric_school": "",
        
        # Intermediate Details
        "inter_board": "",
        "inter_program": "",
        "inter_year": "",
        "inter_total": "",
        "inter_obtained": "",
        "inter_college": "",
        
        # BS Program Preference
        "program_choice": "",
        "program_reason": "",
        "class_preference": "",
        "online_comfort": "",
        
        # Aptitude & Interest
        "logical_aptitude": "",
        "tech_familiarity": "",
        "work_preference": "",
        "programming_experience": "",
        "learning_preference": "",
        
        # Documents
        "documents_ready": "",
        
        # Metadata
        "interview_date": datetime.now().isoformat()
    },
    "interview_data": [],
    "current_question_index": 0,
    "conversation_history": "",
    "result": None
}
@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory('static', filename)
@app.route('/')
def home():
    return send_from_directory('.', 'chatbot.html')
@app.route('/get_students', methods=['GET'])
def get_students():
    try:
        page = int(request.args.get('page', 1))
        per_page = 10
        search_query = request.args.get('search', '')
        
        query = {}
        if search_query:
            query['$or'] = [
                {'full_name': {'$regex': search_query, '$options': 'i'}},
                {'email': {'$regex': search_query, '$options': 'i'}},
                {'program_choice': {'$regex': search_query, '$options': 'i'}}
            ]
        
        total_students = students_collection.count_documents(query)
        students = list(students_collection.find(query)
                       .skip((page - 1) * per_page)
                       .limit(per_page))
        
        # Convert ObjectId to string for JSON serialization
        for student in students:
            student['_id'] = str(student['_id'])
        
        return jsonify({
            'success': True,
            'students': students,
            'totalRecords': total_students
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/send_message', methods=['POST'])
def send_message():
    user_input = request.json['message'].strip()
    response = ""
    
    if interview_state["mode"] == "interview" and interview_state["current_question_index"] < len(fixed_questions):
        # Interview mode - process answer and get next question
        interview_state["interview_data"].append({
            "question": fixed_questions[interview_state["current_question_index"]]["question"],
            "answer": user_input,
            "timestamp": datetime.now().isoformat()
        })
        
        # Extract and store clean data
        current_question = fixed_questions[interview_state["current_question_index"]]
        extracted_value = extract_info(user_input, current_question["type"])
        interview_state["student_data"][current_question["field"]] = extracted_value
        
        # Update conversation history
        interview_state["conversation_history"] += f"\nQ: {current_question['question']}\nA: {user_input}"
        interview_state["current_question_index"] += 1
        
        if interview_state["current_question_index"] >= len(fixed_questions):
            # Interview complete, save to DB
            student_document = {
                **interview_state["student_data"],
                "full_interview": interview_state["interview_data"]
            }
            interview_state["result"] = students_collection.insert_one(student_document)
            response = "✅ Interview completed and saved to database. Would you like program recommendations based on your interview? (yes/no)"
            interview_state["mode"] = "transition"
        else:
            # Get next question
            response = ask_ai("", {
                "current_question_index": interview_state["current_question_index"],
                "conversation_history": interview_state["conversation_history"]
            }, mode="interview")
    
    elif interview_state["mode"] == "transition":
        if user_input.lower() in ['yes', 'y']:
            interview_state["mode"] = "recommendation"
            # Generate recommendations
            recommendations = ask_ai("", interview_state["student_data"], mode="recommendation")
            response = f"🎓 Program Recommendations:\n{recommendations}"
            
            # Save recommendations
            students_collection.update_one(
                {"_id": interview_state["result"].inserted_id},
                {"$set": {"recommendations": recommendations}}
            )
            interview_state["mode"] = "general"
        else:
            response = "You can now ask general questions or type 'menu' to return to main menu."
            interview_state["mode"] = "general"
            
    elif interview_state["mode"] == "recommendation":
        # This mode is handled in the transition phase
        pass
            
    elif interview_state["mode"] == "general":
        if user_input.lower() == 'menu':
            interview_state["mode"] = "menu"
            response = "Main Menu:\n1. Complete admission interview\n2. Get program recommendations (requires completed interview)\n3. Ask general questions\n4. Exit"
        else:
            # General question answering
            response = ask_ai(user_input, mode="general")
    
    else:  # menu mode
        if user_input == "1":
            interview_state["mode"] = "interview"
            interview_state["current_question_index"] = 0
            interview_state["student_data"] = {
                # Personal Information
                "full_name": "",
                "father_name": "",
                "dob": "",
                "gender": "",
                "cnic": "",
                "email": "",
                "mobile": "",
                "city": "",
                
                # Matriculation Details
                "matric_board": "",
                "matric_stream": "",
                "matric_year": "",
                "matric_total": "",
                "matric_obtained": "",
                "matric_school": "",
                
                # Intermediate Details
                "inter_board": "",
                "inter_program": "",
                "inter_year": "",
                "inter_total": "",
                "inter_obtained": "",
                "inter_college": "",
                
                # BS Program Preference
                "program_choice": "",
                "program_reason": "",
                "class_preference": "",
                "online_comfort": "",
                
                # Aptitude & Interest
                "logical_aptitude": "",
                "tech_familiarity": "",
                "work_preference": "",
                "programming_experience": "",
                "learning_preference": "",
                
                # Documents
                "documents_ready": "",
                
                # Metadata
                "interview_date": datetime.now().isoformat()
            }
            interview_state["interview_data"] = []
            interview_state["conversation_history"] = ""
            response = ask_ai("", {
                "current_question_index": interview_state["current_question_index"],
                "conversation_history": interview_state["conversation_history"]
            }, mode="interview")
            
        elif user_input == "2":
            if interview_state["student_data"].get("full_name"):
                interview_state["mode"] = "recommendation"
                recommendations = ask_ai("", interview_state["student_data"], mode="recommendation")
                response = f"🎓 Program Recommendations:\n{recommendations}"
                interview_state["mode"] = "general"
            else:
                response = "Please complete the admission interview first to get personalized recommendations."
                
        elif user_input == "3":
            interview_state["mode"] = "general"
            response = "You can now ask general questions. Type 'menu' to return to main menu."
            
        elif user_input == "4":
            response = "exit"
        else:
            response = "Invalid choice. Please enter 1, 2, 3, or 4."
    
    return jsonify({"response": response})

def open_browser():
    webbrowser.open_new('http://127.0.0.1:5000/')


if __name__ == '__main__':
    if os.environ.get('WERKZEUG_RUN_MAIN') != 'true':
        threading.Timer(1.25, open_browser).start()
    app.run(debug=False)